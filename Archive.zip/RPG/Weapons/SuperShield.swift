//
//  SuperShield.swift
//  RPG
//
//  Created by admin on 18/12/2018.
//  Copyright © 2018 Jotaro. All rights reserved.
//

import Foundation

class SuperShield: Weapon {
    init() {
        super.init(name: "superShield", dmg: 20)
    }
}
