//
//  SuperSword.swift
//  RPG
//
//  Created by admin on 18/12/2018.
//  Copyright © 2018 Jotaro. All rights reserved.
//

import Foundation

class SuperSword: Weapon {
    init() {
        super.init(name: "superSword", dmg: 50)
    }
}
