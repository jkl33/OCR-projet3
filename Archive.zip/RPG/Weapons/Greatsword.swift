//
//  Greatsword.swift
//  RPG
//
//  Created by admin on 18/12/2018.
//  Copyright © 2018 Jotaro. All rights reserved.
//

import Foundation

class GreatSword: Weapon {
    init() {
        super.init(name: "greatSword", dmg: 20)
    }
}
