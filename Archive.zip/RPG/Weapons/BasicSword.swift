//
//  WarriorWeapons.swift
//  RPG
//
//  Created by admin on 04/12/2018.
//  Copyright © 2018 Jotaro. All rights reserved.
//

import Foundation

class BasicSword: Weapon {
    init() {
        super.init(name: "basicSword", dmg: 10)
    }
}
