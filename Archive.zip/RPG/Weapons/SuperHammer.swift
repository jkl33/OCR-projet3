//
//  SuperHammer.swift
//  RPG
//
//  Created by admin on 18/12/2018.
//  Copyright © 2018 Jotaro. All rights reserved.
//

import Foundation

class SuperHammer: Weapon {
    init() {
        super.init(name: "superHammer", dmg: 75)
    }
}
