//
//  MageWeapons.swift
//  RPG
//
//  Created by admin on 11/12/2018.
//  Copyright © 2018 Jotaro. All rights reserved.
//

import Foundation

class BasicCrystalBall: Weapon {
    init() {
        super.init(name: "basicCrystalBall", dmg: -10)
    }
}
