//
//  DwarfWeapons.swift
//  RPG
//
//  Created by admin on 11/12/2018.
//  Copyright © 2018 Jotaro. All rights reserved.
//

import Foundation

class BasicHammer: Weapon {
    init() {
        super.init(name: "basicHammer", dmg: 15)
    }
}
