//
//  main.swift
//  RPG
//
//  Created by admin on 01/11/2018.
//  Copyright © 2018 Jotaro. All rights reserved.
//

import Foundation
var theGame = Game()
theGame.start()
